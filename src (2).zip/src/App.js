import React from 'react';
import { CssBaseline, Box } from '@mui/material';
import { BrowserRouter as Router, Route, Routes, useNavigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Manage from './components/Manage';
import Create from './components/Create';
import Approve from './components/Approve';
import ViewTab from './components/ViewTab';
import EditTab from './components/EditTab';
import LoginPage from './components/LoginPage/LoginPage';
import Home from './components/Home'; // New import

// MainLayout component to pass down the user and logout functionality
const MainLayout = ({ children }) => {
  const user = { name: 'John Doe' };
  const navigate = useNavigate(); // Hook for programmatic navigation

  // Logout handler function
  const handleLogout = () => {
    // Clear session, user data, or tokens
    console.log('User logged out.');
    // Redirect to the login page
    navigate('/');
  };

  return (
    <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <CssBaseline />
      <Sidebar />
      <Box sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Pass user and handleLogout to Header */}
        <Header user={user} onLogout={handleLogout} />
        <Box 
          component="main" 
          sx={{ 
            flexGrow: 1, 
            p: 3, 
            overflowY: 'auto',
            mt: '64px', // Adjust this value based on your header height
          }}
        >
          {children}
        </Box>
      </Box>
    </Box>
  );
};

const App = () => {
  return (
    <Router>
      <Routes>
        {/* LoginPage Route */}
        <Route path="/" element={<LoginPage />} />
        {/* Protected routes go under MainLayout */}
        <Route
          path="/*"
          element={
            <MainLayout>
              <Routes>
                <Route path="/home" element={<Home />} /> {/* New route */}
                <Route path="/manage" element={<Manage />} />
                <Route path="/create" element={<Create />} />
                <Route path="/approve" element={<Approve />} />
                <Route path="/view" element={<ViewTab />} />
                <Route path="/view/:batchRefId" element={<EditTab />} />
                <Route path="/edit" element={<EditTab />} />
              </Routes>
            </MainLayout>
          }
        />
      </Routes>
    </Router>
  );
};

export default App;
