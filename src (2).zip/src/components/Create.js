// src/components/Create.js
import React, { useState } from 'react';
import { Box, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Button, FormControl, InputLabel, Select, MenuItem, Typography } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';

const Create = () => {
  const initialRows = [
    { batchRefId: 'BR001', payeeBankId: 'PB001', payeeName: 'John Doe', accountNum: '123456789', amount: 1000 },
    { batchRefId: 'BR002', payeeBankId: 'PB002', payeeName: 'Jane Smith', accountNum: '987654321', amount: 1500 },
    { batchRefId: 'BR003', payeeBankId: 'PB003', payeeName: 'Alice Johnson', accountNum: '456789123', amount: 2000 },
  ];

  const [rows, setRows] = useState(initialRows);
  const [debitAccount, setDebitAccount] = useState('');
  const [date, setDate] = useState('');
  const [currency, setCurrency] = useState('USD');

  // Calculate total amount and total number of transactions
  const totalAmount = rows.reduce((sum, row) => sum + row.amount, 0);
  const totalTransactions = rows.length;

  const handleEdit = (index, field, value) => {
    const updatedRows = [...rows];
    updatedRows[index][field] = value;
    setRows(updatedRows);
  };

  const handleAmountChange = (index, value) => {
    const numericValue = parseFloat(value);

    if (!isNaN(numericValue)) {
      const updatedRows = [...rows];
      updatedRows[index].amount = numericValue;
      setRows(updatedRows);
    }
  };

  const handleDelete = (index) => {
    const updatedRows = [...rows];
    updatedRows.splice(index, 1);
    setRows(updatedRows);
  };

  const handleAddRow = () => {
    const newRow = {
      batchRefId: `BR${rows.length + 1}`,
      payeeBankId: '',
      payeeName: '',
      accountNum: '',
      amount: 0,
      status: 'Pending',
    };

    setRows([...rows, newRow]);
  };

  const handleSaveDraft = () => {
    // Logic to save draft
    console.log("Draft saved:", rows);
  };

  const handleSubmit = () => {
    // Logic to submit the data
    console.log("Data submitted:", rows);
  };

  return (
    <Box sx={{ marginTop: '20px' }}>
      <Typography variant="h4" gutterBottom>
        Create Payments
      </Typography>
      {/* New div with text boxes and dropdowns */}
      <Box display="flex" justifyContent="space-between" gap={2} marginBottom={2}>
        <Box display="flex" alignItems="center" gap={1}>
          <TextField
            label="Total Amount"
            value={currency === 'USD' ? `$${totalAmount.toLocaleString()}` : `₹${(totalAmount * 80).toLocaleString()}`}
            InputProps={{
              readOnly: true,
            }}
            variant="outlined"
            sx={{ width: '200px' }} // Set a fixed width for the text box
          />

          <FormControl sx={{ width: '100px' }}>
            <Select
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
              size="small"
            >
              <MenuItem value="USD">USD</MenuItem>
              <MenuItem value="INR">INR</MenuItem>
            </Select>
          </FormControl>
        </Box>

        <TextField
          label="Total Transactions"
          value={totalTransactions} // Display total number of transactions
          InputProps={{
            readOnly: true,
          }}
          variant="outlined"
          sx={{ width: '200px' }} // Set a fixed width for the text box
        />

        <FormControl sx={{ width: '200px' }}>
          <InputLabel>Debit Accounts</InputLabel>
          <Select
            value={debitAccount}
            onChange={(e) => setDebitAccount(e.target.value)}
          >
            <MenuItem value="">Select Debit Account</MenuItem>
            <MenuItem value="Account1">Account 1</MenuItem>
            <MenuItem value="Account2">Account 2</MenuItem>
            <MenuItem value="Account3">Account 3</MenuItem>
          </Select>
        </FormControl>

        <FormControl sx={{ width: '200px' }}>
          <InputLabel>Date</InputLabel>
          <Select
            value={date}
            onChange={(e) => setDate(e.target.value)}
          >
            <MenuItem value="">Select Date</MenuItem>
            <MenuItem value="2024-01-01">2024-01-01</MenuItem>
            <MenuItem value="2024-02-01">2024-02-01</MenuItem>
            <MenuItem value="2024-03-01">2024-03-01</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Batch Reference ID</TableCell>
              <TableCell>Payee Bank ID</TableCell>
              <TableCell>Payee Name</TableCell>
              <TableCell>Account Num</TableCell>
              <TableCell>Amount</TableCell>
              {/* <TableCell>Status</TableCell> */}
              <TableCell>Delete</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row, index) => (
              <TableRow key={row.batchRefId}>
                <TableCell>{row.batchRefId}</TableCell>
                <TableCell>
                  <TextField
                    variant="outlined"
                    value={row.payeeBankId}
                    onChange={(e) => handleEdit(index, 'payeeBankId', e.target.value)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <TextField
                    variant="outlined"
                    value={row.payeeName}
                    onChange={(e) => handleEdit(index, 'payeeName', e.target.value)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <TextField
                    variant="outlined"
                    value={row.accountNum}
                    onChange={(e) => handleEdit(index, 'accountNum', e.target.value)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <TextField
                    variant="outlined"
                    value={row.amount}
                    onChange={(e) => handleAmountChange(index, e.target.value)}
                    size="small"
                  />
                </TableCell>
                {/* <TableCell>{row.status}</TableCell> */}
                <TableCell>
                  <Button variant="contained" color="error" onClick={() => handleDelete(index)}>
                    <DeleteIcon />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Add Row Button */}
      <Box display="flex" justifyContent="flex-end" marginTop={2}>
        <Button variant="contained" color="primary" onClick={handleAddRow}>
          <AddIcon />
          Add Row
        </Button>
      </Box>

      {/* Save Draft and Submit Buttons */}
      <Box display="flex" justifyContent="flex-end" marginTop={2}>
        <Button variant="outlined" color="primary" onClick={handleSaveDraft} sx={{ marginRight: 2 }}>
          Save Draft
        </Button>
        <Button variant="contained" color="primary" onClick={handleSubmit}>
          Submit
        </Button>
      </Box>
    </Box>
  );
};

export default Create;