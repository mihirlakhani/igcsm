import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  FormControl, 
  InputLabel, 
  Select, 
  MenuItem, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  Button
} from '@mui/material';
import { Download } from 'lucide-react';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

const ViewTab = () => {
  const [debitAccounts, setDebitAccounts] = useState([]);
  const [currencies, setCurrencies] = useState(['USD', 'EUR', 'GBP']); // Example currencies
  const [selectedAccount, setSelectedAccount] = useState('');
  const [selectedCurrency, setSelectedCurrency] = useState('');
  const [summaryData, setSummaryData] = useState([]);

  useEffect(() => {
    // Fetch debit accounts from your API
    fetchDebitAccounts();
  }, []);

  const fetchDebitAccounts = async () => {
    // Replace this with your actual API call
    const response = await fetch('/api/debit-accounts');
    const data = await response.json();
    setDebitAccounts(data);
  };

  const handleAccountChange = (event) => {
    setSelectedAccount(event.target.value);
    fetchSummaryData(event.target.value, selectedCurrency);
  };

  const handleCurrencyChange = (event) => {
    setSelectedCurrency(event.target.value);
    fetchSummaryData(selectedAccount, event.target.value);
  };

  const fetchSummaryData = async (accountId, currency) => {
    if (accountId && currency) {
      // Replace this with your actual API call
      const response = await fetch(`/api/summary?accountId=${accountId}&currency=${currency}`);
      const data = await response.json();
      setSummaryData(data);
    }
  };

  const downloadPDF = () => {
    const doc = new jsPDF();
    doc.text('Payroll Summary Report', 14, 15);
    doc.autoTable({
      head: [['Batch Code', 'Transaction Date', 'Status', 'Total Balance', 'Created By']],
      body: summaryData.map(row => [
        row.batchCode,
        row.transactionDate,
        row.status,
        row.totalBalance,
        row.createdBy
      ]),
      startY: 20
    });
    doc.save('payroll_summary.pdf');
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" gutterBottom>View Payroll Summary</Typography>
      
      <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
        <FormControl fullWidth>
          <InputLabel>Debit Account</InputLabel>
          <Select value={selectedAccount} onChange={handleAccountChange}>
            {debitAccounts.map((account) => (
              <MenuItem key={account.id} value={account.id}>
                {account.accountNumber}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        
        <FormControl fullWidth>
          <InputLabel>Currency</InputLabel>
          <Select value={selectedCurrency} onChange={handleCurrencyChange}>
            {currencies.map((currency) => (
              <MenuItem key={currency} value={currency}>
                {currency}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </Box>

      {summaryData.length > 0 && (
        <>
          <TableContainer component={Paper} sx={{ mb: 3 }}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Batch Code</TableCell>
                  <TableCell>Transaction Date</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Total Balance</TableCell>
                  <TableCell>Created By</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {summaryData.map((row) => (
                  <TableRow key={row.batchCode}>
                    <TableCell>{row.batchCode}</TableCell>
                    <TableCell>{row.transactionDate}</TableCell>
                    <TableCell>{row.status}</TableCell>
                    <TableCell>{row.totalBalance}</TableCell>
                    <TableCell>{row.createdBy}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>

          <Button 
            variant="contained" 
            startIcon={<Download />} 
            onClick={downloadPDF}
          >
            Download PDF
          </Button>
        </>
      )}
    </Box>
  );
};

export default ViewTab;