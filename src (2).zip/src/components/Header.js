import React, { useState } from 'react';
import { AppBar, Toolbar, Typography, IconButton, Menu, MenuItem } from '@mui/material';
import PersonIcon from '@mui/icons-material/Person';
import logo from '../assets/image.png'; // Adjust the path based on your project structure
import { useNavigate } from 'react-router-dom';

const Header = ({ user, onLogout }) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const navigate = useNavigate(); // Initialize navigate function

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleLogout = () => {
    handleMenuClose();
    onLogout(); // Trigger the logout function passed from App.js
  };

  const handleHome = () => {
    handleMenuClose();
    navigate('/home'); // Navigate to the home page
  };

  return (
    <AppBar position="fixed" sx={{ backgroundColor: 'white', color: 'blue' }}>
      <Toolbar>
        <img src={logo} alt="Logo" style={{ height: '50px', marginRight: '16px' }} />
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          Payroll Management System
        </Typography>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <span style={{ marginRight: '16px' }}>Welcome, {user.name}</span>
          <IconButton color="inherit" onClick={handleMenuOpen}>
            <PersonIcon />
          </IconButton>
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
          >
            <MenuItem onClick={handleHome}>Home</MenuItem> {/* Home button */}
            <MenuItem onClick={handleLogout}>Logout</MenuItem>
          </Menu>
        </div>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
