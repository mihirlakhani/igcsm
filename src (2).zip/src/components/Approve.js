import React from 'react';
import { Box, Typography } from '@mui/material';
import { ApprovalTable } from './ApprovalTable';

const Approve = () => {
  return (
    
    <Box sx={{ padding: '10px'}}>
      <Typography variant="h4" gutterBottom>
        Approve Payments
      </Typography>
      {/* Add your approval logic here */}
      <ApprovalTable/>
    </Box>
  );
};

export default Approve;