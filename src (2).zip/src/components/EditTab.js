import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Box, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Button, Typography,FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';

const EditTab = () => {
  const { batchRefId } = useParams(); // Get the batchRefId from the URL
  const [rows, setRows] = useState([]);

  useEffect(() => {
    // Fetch payee details based on the batchRefId
    const fetchPayeeDetails = () => {
      // Sample data based on the batchRefId
      const payeeDetails = [
        { batchRefId, payeeBankId: 'PB001', payeeName: 'John Doe', accountNum: '123456789', amount: 1000 },
        { batchRefId, payeeBankId: 'PB002', payeeName: 'Jane Smith', accountNum: '987654321', amount: 1500 },
      ];
      setRows(payeeDetails);
    };

    fetchPayeeDetails();
  }, [batchRefId]);

  const handleEdit = (index, field, value) => {
    const updatedRows = [...rows];
    updatedRows[index][field] = value;
    setRows(updatedRows);
  };

  const handleAmountChange = (index, value) => {
    const numericValue = parseFloat(value);
    if (!isNaN(numericValue)) {
      const updatedRows = [...rows];
      updatedRows[index].amount = numericValue;
      setRows(updatedRows);
    }
  };

  const handleDelete = (index) => {
    const updatedRows = [...rows];
    updatedRows.splice(index, 1);
    setRows(updatedRows);
  };

  const handleAddRow = () => {
    const newRow = {
      batchRefId,
      payeeBankId: '',
      payeeName: '',
      accountNum: '',
      amount: 0,
    };
    setRows([...rows, newRow]);
  };

  // Calculate total amount for the current batch
  const totalAmount = rows.reduce((sum, row) => sum + row.amount, 0);

  return (
    <Box sx={{ marginTop: '16px' }}>
      <Typography variant='h6' marginBottom={4}>Edit batch</Typography>
      {/* New div with text boxes and dropdowns */}
      <Box display="flex" justifyContent="space-between" gap={2} marginBottom={2}>
        <TextField
          label="Batch Reference ID"
          value={batchRefId}
          InputProps={{
            readOnly: true,
          }}
          variant="outlined"
          sx={{ width: '200px' }} // Set a fixed width for the text box
        />

        <TextField
          label="Total Amount"
          value={`$${totalAmount.toLocaleString()}`} // Display total amount
          InputProps={{
            readOnly: true,
          }}
          variant="outlined"
          sx={{ width: '200px' }} // Set a fixed width for the text box
        />
      </Box>

      {/* Table */}
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Payee Bank ID</TableCell>
              <TableCell>Payee Name</TableCell>
              <TableCell>Account Num</TableCell>
              <TableCell>Amount</TableCell>
              <TableCell>Delete</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row, index) => (
              <TableRow key={row.batchRefId + index}>
                <TableCell>
                  <TextField
                    variant="outlined"
                    value={row.payeeBankId}
                    onChange={(e) => handleEdit(index, 'payeeBankId', e.target.value)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <TextField
                    variant="outlined"
                    value={row.payeeName}
                    onChange={(e) => handleEdit(index, 'payeeName', e.target.value)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <TextField
                    variant="outlined"
                    value={row.accountNum}
                    onChange={(e) => handleEdit(index, 'accountNum', e.target.value)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <TextField
                    variant="outlined"
                    value={row.amount}
                    onChange={(e) => handleAmountChange(index, e.target.value)}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  <Button variant="contained" color="error" onClick={() => handleDelete(index)}>
                    <DeleteIcon />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Add Row Button */}
      <Box display="flex" justifyContent="flex-end" marginTop={2}>
        <Button variant="contained" color="primary" onClick={handleAddRow}>
          <AddIcon />
          Add Row
        </Button>
      </Box>

      {/* Save Draft and Submit Buttons */}
      <Box display="flex" justifyContent="flex-end" marginTop={2}>
        <Button variant="outlined" color="primary" onClick={() => console.log("Draft saved:", rows)} sx={{ marginRight: 2 }}>
          Save Draft
        </Button>
        <Button variant="contained" color="primary" onClick={() => console.log("Data submitted:", rows)}>
          Submit
        </Button>
      </Box>
    </Box>
  );
};

export default EditTab;