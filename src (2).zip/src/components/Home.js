import React, { useState, useEffect } from 'react';
import { Box, Typography, Grid, Paper, CircularProgress, useTheme } from '@mui/material';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Wallet, Users, FileText, AlertCircle } from 'lucide-react';

const DashboardCard = ({ title, value, icon, color }) => {
  const theme = useTheme();
  return (
    <Paper 
      elevation={3} 
      sx={{ 
        p: 3, 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'space-between',
        background: `linear-gradient(45deg, ${color} 30%, ${theme.palette.background.paper} 90%)`,
        color: theme.palette.getContrastText(color),
        transition: '0.3s',
        '&:hover': {
          transform: 'translateY(-5px)',
          boxShadow: theme.shadows[10],
        }
      }}
    >
      <Box>
        <Typography variant="h6" component="div" sx={{ mb: 1, fontWeight: 'bold' }}>
          {title}
        </Typography>
        <Typography variant="h4" component="div" sx={{ fontWeight: 'bold' }}>
          {value}
        </Typography>
      </Box>
      <Box sx={{ opacity: 0.7 }}>
        {icon}
      </Box>
    </Paper>
  );
};

const Home = () => {
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState(null);
  const theme = useTheme();

  useEffect(() => {
    // Simulating API call to fetch dashboard data
    setTimeout(() => {
      setDashboardData({
        totalUsers: 150,
        totalAccounts: 50,
        pendingBatches: 5,
        totalTransactions: 1000,
        recentTransactions: [
          { date: 'Jan', amount: 4000 },
          { date: 'Feb', amount: 3000 },
          { date: 'Mar', amount: 5000 },
          { date: 'Apr', amount: 4500 },
          { date: 'May', amount: 6000 },
          { date: 'Jun', amount: 5500 },
        ],
        batchStatuses: [
          { name: 'Pending', value: 30 },
          { name: 'Approved', value: 50 },
          { name: 'Rejected', value: 20 },
        ],
      });
      setLoading(false);
    }, 1500);
  }, []);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box sx={{ flexGrow: 1, p: 3, background: theme.palette.background.default }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', color: theme.palette.primary.main, mb: 4 }}>
        Payroll Management Dashboard
      </Typography>
      <Grid container spacing={4}>
        <Grid item xs={12} sm={6} md={3}>
          <DashboardCard 
            title="Total Users" 
            value={dashboardData.totalUsers} 
            icon={<Users size={40} />} 
            color={theme.palette.primary.main}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <DashboardCard 
            title="Debit Accounts" 
            value={dashboardData.totalAccounts} 
            icon={<Wallet size={40} />} 
            color={theme.palette.secondary.main}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <DashboardCard 
            title="Pending Batches" 
            value={dashboardData.pendingBatches} 
            icon={<AlertCircle size={40} />} 
            color={theme.palette.warning.main}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <DashboardCard 
            title="Total Transactions" 
            value={dashboardData.totalTransactions} 
            icon={<FileText size={40} />} 
            color={theme.palette.success.main}
          />
        </Grid>
        <Grid item xs={12} md={8}>
          <Paper elevation={3} sx={{ p: 3, height: '100%'}}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold' }}>
              Recent Transactions
            </Typography>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={dashboardData.recentTransactions}>
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="amount" fill={theme.palette.primary.main} />
              </BarChart>
            </ResponsiveContainer>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
  <Paper elevation={3} sx={{ p: 2, height: '100%'}}> {/* Adjusted padding */}
    <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold' }}>
      Batch Status
    </Typography>
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={dashboardData.batchStatuses}
          cx="50%"
          cy="50%"
          labelLine={false}
          outerRadius={100}
          fill="#8884d8"
          dataKey="value"
          label={({ percent }) => ` ${(percent * 100).toFixed(0)}%`}
        >
          {dashboardData.batchStatuses.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
          ))}
        </Pie>
        <Tooltip />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  </Paper>
</Grid>

      </Grid>
    </Box>
  );
};

export default Home;