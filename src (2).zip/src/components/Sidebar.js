import React from 'react';
import { List, ListItem, ListItemText, Drawer, Typography, Box } from '@mui/material';
import { Link } from 'react-router-dom';
import CreateIcon from '@mui/icons-material/Create';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import ApprovalIcon from '@mui/icons-material/Approval';
import VisibilityIcon from '@mui/icons-material/Visibility';

const Sidebar = () => {
  return (
    <Drawer
      variant="permanent"
      sx={{
        width: 250,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: 250,
          boxSizing: 'border-box',
          position: 'fixed',
          top: 64,
          height: 'calc(100% - 64px)',
          backgroundImage: 'linear-gradient(90deg, #2c3a87, #0061c7)',
        },
      }}
    >
      <div style={{ padding: '16px' }}>
        <Typography variant="h6" component="div" align="center" color="white">
          Payroll Management
        </Typography>
      </div>
      <List>
        {[
          { text: 'Create', icon: <CreateIcon />, to: '/create' },
          { text: 'Manage', icon: <ManageAccountsIcon />, to: '/manage' },
          { text: 'Approve', icon: <ApprovalIcon />, to: '/approve' },
          { text: 'View', icon: <VisibilityIcon />, to: '/view' },
        ].map((item) => (
          <ListItem
            key={item.text}
            button
            component={Link}
            to={item.to}
            sx={{
              color: 'white',
              '&:hover': {
                backgroundColor: 'rgba(255, 255, 255, 0.1)',
              },
            }}
          >
            <Box
              sx={{
                display: 'flex',
                alignItems: 'flex-end',
                width: '100%',
                '& .MuiSvgIcon-root': {
                  color: 'white',
                  marginRight: 2,
                  marginBottom: '4px', // Adjust this value to fine-tune vertical alignment
                },
              }}
            >
              {item.icon}
              <ListItemText
                primary={item.text}
                primaryTypographyProps={{
                  style: { color: 'white' },
                }}
              />
            </Box>
          </ListItem>
        ))}
      </List>
    </Drawer>
  );
};

export default Sidebar;