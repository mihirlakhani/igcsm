import React from 'react';
import { Box, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Stack, Modal, Typography } from '@mui/material';
import TextField from '@mui/material/TextField';
import Alert from '@mui/material/Alert';

export const ApprovalTable = () => {
  const initialRows = [
    { batchRefId: 'BR001', Batched_BY: 'Ram', Batched_ON: '01/08/2024', NumTrans: 5, Amount: 9000, Status: 'Pending', Remarks: '-', isActionTaken: false },
    { batchRefId: 'BR002', Batched_BY: 'Shyam', Batched_ON: '01/08/2024', NumTrans: 7, Amount: 1500, Status: 'Pending', Remarks: '-', isActionTaken: false },
    { batchRefId: 'BR003', Batched_BY: 'Krism', Batched_ON: '01/08/2024', NumTrans: 8, Amount: 2000, Status: 'Pending', Remarks: '-', isActionTaken: false },
  ];

  const [rows, setRows] = React.useState(initialRows);
  const [open, setOpen] = React.useState(false);
  const [actionType, setActionType] = React.useState('');
  const [selectedBatchId, setSelectedBatchId] = React.useState(null);
  const [remarks, setRemarks] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [passwordError, setPasswordError] = React.useState('');
  const [validPassword, setValidPassword] = React.useState(false);

  const handleOpen = (batchId, type) => {
    setActionType(type);
    setSelectedBatchId(batchId);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setRemarks('');
    setPassword('');
    setPasswordError('');
  };

  const validatePassword = (password) => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasLowerCase = /[a-z]/.test(password);
    const hasNumber = /\d/.test(password);
    const hasSpecialChar = /[!@#$%^&*]/.test(password);

    if (password.length < minLength) {
      setPasswordError(`Password must be at least ${minLength} characters long.`);
      setValidPassword(false);
    } else if (!hasUpperCase) {
      setPasswordError('Password must contain at least one uppercase letter.');
      setValidPassword(false);
    } else if (!hasLowerCase) {
      setPasswordError('Password must contain at least one lowercase letter.');
      setValidPassword(false);
    } else if (!hasNumber) {
      setPasswordError('Password must contain at least one number.');
      setValidPassword(false);
    } else if (!hasSpecialChar) {
      setPasswordError('Password must contain at least one special character (!@#$%^&*).');
      setValidPassword(false);
    } else {
      setPasswordError('');
      setValidPassword(true);
    }
  };

  const handlePasswordChange = (event) => {
    const passwordInput = event.target.value;
    setPassword(passwordInput);
    validatePassword(passwordInput);
  };

  const handleSubmit = () => {
    if (validPassword) {
      // Update the remarks, status, and mark the action as taken
      setRows((prevRows) =>
        prevRows.map((row) =>
          row.batchRefId === selectedBatchId
            ? {
                ...row,
                Remarks: remarks,
                Status: actionType === 'Approve' ? 'Approved' : 'Rejected',
                isActionTaken: true,
              }
            : row
        )
      );
      handleClose();
    }
  };

  const modalStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    borderRadius: '8px',
    boxShadow: 24,
    p: 4,
  };

  return (
    <div>
      <Box sx={{ marginTop: '30px', width: 900,   
          borderRadius: 1 }}>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow >
                <TableCell align="center">Batch RefID</TableCell>
                <TableCell align="center">Created By</TableCell>
                <TableCell align="center">Created On</TableCell>
                <TableCell align="center">No. of Transactions</TableCell>
                <TableCell align="center">Total Amount</TableCell>
                <TableCell align="center">Status</TableCell>
                <TableCell align="center">Remarks</TableCell>
                <TableCell align="center">Action</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {rows.map((row) => (
                <TableRow key={row.batchRefId}>
                  <TableCell align="center">{row.batchRefId}</TableCell>
                  <TableCell align="center">{row.Batched_BY}</TableCell>
                  <TableCell align="center">{row.Batched_ON}</TableCell>
                  <TableCell align="center">{row.NumTrans}</TableCell>
                  <TableCell align="center">{row.Amount}</TableCell>
                  <TableCell align="center">{row.Status}</TableCell>
                  <TableCell align="center">{row.Remarks}</TableCell>
                  <TableCell align="center">
                    <Stack spacing={1} direction="row" justifyContent="center">
                      <Button
                        variant="contained"
                        color="success"
                        onClick={() => handleOpen(row.batchRefId, 'Approve')}
                        disabled={row.isActionTaken}
                      >
                        Approve
                      </Button>
                      <Button
                        variant="contained"
                        color="error"
                        onClick={() => handleOpen(row.batchRefId, 'Reject')}
                        disabled={row.isActionTaken}
                      >
                        Reject
                      </Button>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>

      <Modal open={open} onClose={handleClose}>
        <Box sx={modalStyle}>
          <Typography variant="h6" component="h2">{actionType === 'Approve' ? 'Approval' : 'Rejection'}</Typography>

          <TextField
            required
            margin="dense"
            id="password"
            name="password"
            label="Password"
            type="password"
            fullWidth
            variant="standard"
            value={password}
            onChange={handlePasswordChange}
          />
          {passwordError && <Alert severity="error">{passwordError}</Alert>}

          <TextField
            required
            margin="dense"
            id="remarks"
            name="remarks"
            label="Remarks"
            type="text"
            fullWidth
            variant="standard"
            value={remarks}
            onChange={(e) => setRemarks(e.target.value)}
          />

          <Stack spacing={2} direction="row" justifyContent="flex-end" sx={{ mt: 2 }}>
            <Button onClick={handleClose}>Cancel</Button>
            <Button variant="contained" disabled={!validPassword} onClick={handleSubmit}>Submit</Button>
          </Stack>
        </Box>
      </Modal>
    </div>
  );
};


