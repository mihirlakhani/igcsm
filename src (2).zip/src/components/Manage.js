// src/components/Manage.js
import React, { useState } from 'react';
import { Box, Typography, Tabs, Tab } from '@mui/material';
import ViewTab from './ViewTab';
import EditTab from './EditTab';

const Manage = () => {
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ padding: '16px' }}>
      <Typography variant="h4" gutterBottom>
        Manage Payments
      </Typography>
      <Tabs value={value} onChange={handleChange} centered>
        <Tab label="View" />
        {/* <Tab label="Edit" /> */}
      </Tabs>

      {value === 0 && <ViewTab />}
      {/* {value === 1 && <EditTab />} */}
    </Box>
  );
};

export default Manage;