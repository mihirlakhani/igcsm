import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Typography, 
  TextField, 
  Button, 
  Link, 
  FormControl, 
  InputLabel, 
  Select, 
  MenuItem, 
  Snackbar,
  InputAdornment,
  IconButton
} from '@mui/material';
import { Visibility, VisibilityOff, Email, Lock } from '@mui/icons-material';
import './LoginPage.css';

// Updated dummy user data with loginAttempts and isLocked
const dummyUsers = [
  { email: 'user1@example.com', password: 'Password123', isLocked: false, loginAttempts: 0 },
  { email: 'user2@example.com', password: 'Password456', isLocked: false, loginAttempts: 0 },
  { email: 'user3@example.com', password: 'Password789', isLocked: false, loginAttempts: 0 },
];

const LoginPage = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isResetPassword, setIsResetPassword] = useState(false);
  const [secretQuestion, setSecretQuestion] = useState('');
  const [secretAnswer, setSecretAnswer] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [snackbarOpen, setSnackbarOpen] = useState(false);

  // Function to handle login
  const handleLogin = (event) => {
    event.preventDefault();

    // Find the user in dummyUsers
    const user = dummyUsers.find(u => u.email === email);

    if (!user) {
      setError('User not found');
      setSnackbarOpen(true);
      return;
    }

    // Check if the user is locked
    if (user.isLocked) {
      setError('Your account is locked due to multiple incorrect login attempts.');
      setSnackbarOpen(true);
      return;
    }

    // Check password
    if (user.password === password) {
      // Successful login, reset loginAttempts and error
      user.loginAttempts = 0;
      setError('');
      navigate('/home');
    } else {
      // Increment login attempts if login fails
      user.loginAttempts += 1;

      // If login attempts reach 3, lock the account
      if (user.loginAttempts >= 3) {
        user.isLocked = true;
        setError('Your account is locked due to 3 incorrect login attempts.');
      } else {
        setError('Invalid email or password');
      }

      setSnackbarOpen(true);
    }
  };

  // Function to handle password reset
  const handleResetPassword = (event) => {
    event.preventDefault();
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match');
      setSnackbarOpen(true);
      return;
    }
    // In a real app, you would handle the password reset logic here
    setSuccessMessage('Password reset successful!');
    setSnackbarOpen(true);
    setIsResetPassword(false);
    // Clear form fields
    setEmail('');
    setPassword('');
    setSecretQuestion('');
    setSecretAnswer('');
    setNewPassword('');
    setConfirmPassword('');
  };

  const handleSnackbarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackbarOpen(false);
  };

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <div className="left-column"></div>
        <div className="right-column">
          <div className="login-box">
            <Typography variant="h5" component="h2" gutterBottom align="center">
              {isResetPassword ? 'Reset Password' : 'Log In'}
            </Typography>
            <form onSubmit={isResetPassword ? handleResetPassword : handleLogin}>
              <TextField
                label="Email"
                type="email"
                fullWidth
                margin="normal"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <Email />
                    </InputAdornment>
                  ),
                }}
              />
              {!isResetPassword && (
                <TextField
                  label="Password"
                  type={showPassword ? 'text' : 'password'}
                  fullWidth
                  margin="normal"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <Lock />
                      </InputAdornment>
                    ),
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          aria-label="toggle password visibility"
                          onClick={handleTogglePasswordVisibility}
                          edge="end"
                        >
                          {showPassword ? <VisibilityOff /> : <Visibility />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              )}
              {/* Error message within login box */}
              {error && (
                <Typography variant="body2" color="error" align="center" sx={{ mt: 1 }}>
                  {error}
                </Typography>
              )}
              {isResetPassword && (
                <>
                  <FormControl fullWidth margin="normal">
                    <InputLabel>Secret Question</InputLabel>
                    <Select
                      value={secretQuestion}
                      onChange={(e) => setSecretQuestion(e.target.value)}
                      required
                    >
                      <MenuItem value="pet">What was your first pet's name?</MenuItem>
                      <MenuItem value="school">What was the name of your first school?</MenuItem>
                      <MenuItem value="city">In what city were you born?</MenuItem>
                    </Select>
                  </FormControl>
                  <TextField
                    label="Secret Answer"
                    fullWidth
                    margin="normal"
                    value={secretAnswer}
                    onChange={(e) => setSecretAnswer(e.target.value)}
                    required
                  />
                  <TextField
                    label="New Password"
                    type="password"
                    fullWidth
                    margin="normal"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                  />
                  <TextField
                    label="Confirm New Password"
                    type="password"
                    fullWidth
                    margin="normal"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                  />
                </>
              )}
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
                sx={{ mt: 3, mb: 2, py: 1.5 }}
              >
                {isResetPassword ? 'Reset Password' : 'Log In'}
              </Button>
            </form>
            <Link
              component="button"
              variant="body2"
              onClick={() => setIsResetPassword(!isResetPassword)}
              sx={{ mt: 2, display: 'inline-block' }}
            >
              {isResetPassword ? 'Back to Login' : 'Forgot Password?'}
            </Link>
          </div>
        </div>
      </div>
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={handleSnackbarClose}
        message={error || successMessage}
      />
    </div>
  );
};

export default LoginPage;
